package irc.gui.pbtn;

import java.awt.event.*;
import java.awt.image.*;
import java.awt.*;

/**
 * An ImageButton is a custom GUI widget which is a button with an
 *   image on it.  (The AWT does not have such a widget, presumably
 *   because it's not very portable, but I find that this works fine.)
 */
public class ImageButton extends Canvas implements MouseListener
{
	protected ActionListener actionListener = null;
	public boolean toggle = true;
	private Image upImage = null;		// The image for the "up" state of the button.
	private Image downImage = null;		// The image for the "down" state of the button.
	private Image overImage = null;		// The image for the "mouseover" state of the button.
	private Image image = null;			//The current image for the button (this is always one of upImage, downImage, or overImage).
	private boolean mouseDown = false;	// Are we in a state where a mouse button was pressed down in the button and hasn't been released yet?
	private boolean mouseIn = false;	// Is the mouse cursor over the button?
	private boolean state = false;		// The state of the button (true corresponds to down).
	private boolean type = false;		// The type of button (true corresponds to toggle).
	public ImageButtonGroup group = null;	// The id of this button's group object, if any; buttons in the same group behave like a radio group.
	private int width, height;
	private boolean explicitSize = false;
	private int explicitWidth = 0, explicitHeight=0;
	private Color fontColor=Color.black;
	private Color bgColor = Color.white;
	private String caption = "";

	/**
	 * Create a new button with the given images, group, and initial
	 * state & type.
	 */
	public ImageButton(Image overImage, Image upImage, Image downImage, ImageButtonGroup group, boolean state, boolean type, int explicitWidth, int explicitHeight, String caption) 
	{
		this.group = group;
		this.explicitWidth = (explicitWidth > 0) ? explicitWidth : 60;
		this.explicitHeight = (explicitHeight > 0) ? explicitHeight : 18;
		this.caption = caption;
		if (upImage==null)
		{
			this.upImage=createButton(explicitWidth,explicitHeight,"up");
		}
		else
		{
			this.upImage = upImage;
		}
		if (downImage==null)
		{
			this.downImage=createButton(explicitWidth,explicitHeight,"down");
		}
		else
		{
			this.downImage = downImage;
		}
		if (overImage==null)
		{
			this.overImage=createButton(explicitWidth,explicitHeight,"over");
		}
		else
		{
			this.overImage = overImage;
		}
		if (explicitHeight > 0 || explicitWidth > 0)
		{
			this.explicitSize = true;
		}
		addMouseListener(this);

		/**
		 * Not much point having a group button if it doesn't toggle,
		 * so we ignore stupid requests here.
		 */
		if (group != null)
		{
			this.type = this.toggle;
		}
		else
		{
			this.type = type;
		}
		if (this.type != this.toggle)
		{
			setState(false); 
		}
		else
		{
			setState(state); 
		}
		if (explicitWidth != 0)
		{
			width = explicitWidth;
		}
		else
		{
			width = upImage.getWidth(this);
		}
		if (explicitHeight != 0)
		{
			height = explicitHeight;
		}
		else
		{
			height = upImage.getHeight(this);
		}
		this.image = this.upImage;
		resize(width,height);
	}
	
	/**
	 * Create a new button with the given images and group, and type.
	 * the button starts initially in its "false" (up) state.
	 * A non-null group will force a toggle button regardless of type.
	 */
	public ImageButton(Image overImage, Image upImage, Image downImage, ImageButtonGroup group, boolean type, String caption) 
	{
			this(overImage, upImage, downImage, group, false, type, 0, 0, caption);
	}
	/**
	 * Create a new button with the given images and group, and type.
	 * the button starts initially in its "false" (up) state.
	 * A non-null group will force a toggle button regardless of type.
	 */

	public ImageButton(Image overImage, Image upImage, Image downImage, ImageButtonGroup group, boolean type) 
	{
			this(overImage, upImage, downImage, group, false, type, 0, 0, "");
	}

	/**
	 * Create a new non-toggle button with the given images,
	 * and initially in its "false" (up) state.
	 * If the group is non-null then the button will default to toggle anyway.
	 */
	public ImageButton(Image overImage, Image upImage, Image downImage, ImageButtonGroup group, String caption) 
	{
			this(overImage, upImage, downImage, group, false, false, 0, 0, caption);
	}

	public ImageButton(Image overImage, Image upImage, Image downImage, ImageButtonGroup group) 
	{
			this(overImage, upImage, downImage, group, false, false, 0, 0, "");
	}

	/**
	 * Create a new non-toggle button with the given images, fixed sizes,  and no group.
	 */
	public ImageButton(Image overImage, Image upImage, Image downImage, int explicitWidth, int explicitHeight) 
	{
			this(overImage, upImage, downImage, null, false, false, explicitWidth, explicitHeight, "");
	}

	public ImageButton(Image overImage, Image upImage, Image downImage, int explicitWidth, int explicitHeight, String caption) 
	{
			this(overImage, upImage, downImage, null, false, false, explicitWidth, explicitHeight, caption);
	}
	
	/**
	 * Create a new non-toggle button with the given images, and no group.
	 */
	public ImageButton(Image overImage, Image upImage, Image downImage, String caption) 
	{
			this(overImage, upImage, downImage, null, false, false, 0 , 0, caption);
	}
	
	public ImageButton(Image overImage, Image upImage, Image downImage) 
	{
			this(overImage, upImage, downImage, null, false, false, 0, 0, "");
	}

	public ImageButton( int explicitWidth, int explicitHeight, String caption) 
	{
			this(null, null, null, null, false, false, explicitWidth, explicitHeight, caption);
	}

	public Dimension preferredSize() 
	{
		explicitSize=true;
		if (explicitWidth > 0)
			width=explicitWidth;
		if (explicitHeight > 0)
			height=explicitHeight;
		return (new Dimension(width,height));
	}
	
	public Dimension minimumSize() 
	{
		return (preferredSize());
	}
	
	public Color setBGColor(Color color)
	{
		bgColor = color;
		repaint();
		return color;
	}

	public Color getBGColor()
	{
		return bgColor;
	}

	public Color setFontColor(Color color)
	{
		fontColor = color;
		repaint();
		return color;
	}

	public Color getFontColor()
	{
		return fontColor;
	}

	//----------------------------------------------------
	// LayoutManagers (such as BorderLayout) might call
	// resize or reshape with only 1 dimension of
	// width/height non-zero. In such a case, you still
	// want the other dimension to come from the image
	// itself.
	/** Resizes the ImageLabel. If you don't resize the
	 *  label explicitly, then what happens depends on
	 *  the layout manager. With FlowLayout, as with
	 *  FlowLayout for Labels, the ImageLabel takes its
	 *  minimum size, just enclosing the image. With
	 *  BorderLayout, as with BorderLayout for Labels,
	 *  the ImageLabel is expanded to fill the
	 *  section. Stretching GIF/JPG files does not always
	 *  result in clear looking images. <B>So just as
	 *  with builtin Labels and Buttons, don't
	 *  use FlowLayout if you don't want the Buttons to
	 *  get resized.</B> If you don't use any
	 *  LayoutManager, then the ImageLabel will also
	 *  just fit the image.
	 *  <P>
	 *  Note that if you resize explicitly, you must do
	 *  it <B>before</B> the ImageLabel is added to the
	 *  Container. In such a case, the explicit size
	 *  overrides the image dimensions.
	 *
	 * @see #reshape
	 */
	public void resize(int width, int height) 
	{
		explicitSize=true;
		if (width > 0)
			explicitWidth=width;
		if (height > 0)
			explicitHeight=height;
		super.resize(width, height);
	}
	
	/** Resizes the ImageLabel. If you don't resize the
	 *  label explicitly, then what happens depends on
	 *  the layout manager. With FlowLayout, as with
	 *  FlowLayout for Labels, the ImageLabel takes its
	 *  minimum size, just enclosing the image. With
	 *  BorderLayout, as with BorderLayout for Labels,
	 *  the ImageLabel is expanded to fill the
	 *  section. Stretching GIF/JPG files does not always
	 *  result in clear looking images. <B>So just as
	 *  with builtin Labels and Buttons, don't
	 *  use FlowLayout if you don't want the Buttons to
	 *  get resized.</B> If you don't use any
	 *  LayoutManager, then the ImageLabel will also
	 *  just fit the image.
	 *  <P>
	 *  Note that if you resize explicitly, you must do
	 *  it <B>before</B> the ImageLabel is added to the
	 *  Container. In such a case, the explicit size
	 *  overrides the image dimensions.
	 *
	 * @see #resize
	 */
	public void reshape(int x, int y, int width, int height) 
	{
		explicitSize=true;
		if (width > 0)
			explicitWidth=width;
		if (height > 0)
			explicitHeight=height;
		super.reshape(x, y, width, height);
	}
	
	public void paint(Graphics g) 
	{
		this.setBackground(getBGColor());
		g.setColor(getFontColor());
		if (explicitSize)
		{
			g.drawImage(image, 0, 0, width, height, this);
		}
		else
		{
			g.drawImage(image, 0, 0, this);
		}
		if (caption != "")
		{
			Font font = getFont();
			FontMetrics metrics = getFontMetrics(font);
			/*
			 * Try to alter the font to fit the button.
			 */
			int messWidth = metrics.stringWidth ( caption );
			int fsize=font.getSize();
			while (messWidth >= (width-10) && fsize >= 8 )
			{
				fsize=fsize-1;
				Font f = new Font(font.getName(),font.getStyle(), fsize);
				setFont(f);
				font = getFont();
				metrics = getFontMetrics(font);
				messWidth = metrics.stringWidth ( caption );
			}
			int fontAscent = metrics.getMaxAscent ();
			int fontDescent = metrics.getMaxDescent();
			int startX = getSize().width/2 - messWidth/2;	// Center text
			int startY = getSize().height/2 - fontDescent/2 + fontAscent/2;
			g.drawString(caption, startX, startY);
		}

	}
	
	public void addActionListener(ActionListener l) 
	{
		actionListener = AWTEventMulticaster.add(actionListener,l);
	}
	
	public void removeActionListener(ActionListener l) 
	{
		actionListener = AWTEventMulticaster.remove(actionListener, l);
	}
	
	/**
	 * Return the state (true corresponds to down) of the button.
	 */
	public boolean getState() 
	{
		return state;
	}
	
	public Image createButton(int w, int h, String type)
	{
		int max;
		if (type.equals("down"))
		{
			max=200;
		}
		else
		{
			max=255;
		}
		int pix[] = new int[w * h];
		int index = 0;
		for (int y = 0; y < h; y++) 
		{
			int red = (y * max) / (h - 1);
			for (int x = 0; x < w; x++) 
			{
				int blue = (x * max) / (w - 1);
				if (type.equals("over"))
				{
					pix[index++] = (max << 24) | (blue << 16) | red;
				}
				else
				{
					pix[index++] = (max << 24) | (red << 16) | blue;
				}
			}
		}
		Image img = createImage(new MemoryImageSource(w, h, pix, 0, w));
		return img;
	}

	/**
	 * Set the state of the button.  True corresponds to down.
	 */
	public void setState(boolean state) 
	{
		ImageButtonGroup group = this.group;
		if (group != null) 
		{
			if (state) 
			{
				group.setCurrent(this);
			}
			else if (group.getCurrent() == this) 
			{
				state = true;
			}
		}
		setStateInternal(state);
	}
	
	public void setCaption(String txt)
	{
		caption = txt;
		repaint();
	}

	public String getCaption()
	{
		return caption;
	}

	public void setStateInternal(boolean state) 
	{
		this.state = state;
		if (state && type) 
		{
			image = downImage;
		}
		else 
		{
			image = upImage;
		}
		repaint();
	}
	
	public void mousePressed(MouseEvent evt) 
	{
		image = downImage;
		mouseDown = true;
		repaint();
	}

	public void mouseClicked(MouseEvent evt) 
	{
	}
	
	public void mouseReleased(MouseEvent evt) 
	{
		Point p = evt.getPoint();
		if (mouseDown && mouseIn) 
		{
			ActionEvent ae = new ActionEvent(evt.getSource(),0,getCaption());
			if (actionListener != null) 
			{
				actionListener.actionPerformed(ae);
			}
		}
		if (state && type) 
		{
			image = downImage;
		}
		else 
		{
			image = overImage;
		}
		repaint();
		mouseDown = false;
	}
	
	public void mouseEntered(MouseEvent evt) 
	{
		mouseIn = true;
		if (mouseDown) 
		{
			image = downImage;
		}
		else image = overImage;
		repaint();
	}
	
	public void mouseExited(MouseEvent evt) 
	{
		mouseIn = false;
		if (state && type) 
		{
			image = downImage;
		}
		else 
		{
			image = upImage;
		}
		repaint();
	}
}

