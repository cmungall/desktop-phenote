/*****************************************************/
/*          This java file is a part of the          */
/*                                                   */
/*           -  Plouf's Java IRC Client  -           */
/*                                                   */
/*   Copyright (C)  2002 - 2004 Philippe Detournay   */
/*                                                   */
/*         All contacts : theplouf@yahoo.com         */
/*                                                   */
/*  PJIRC is free software; you can redistribute     */
/*  it and/or modify it under the terms of the GNU   */
/*  General Public License as published by the       */
/*  Free Software Foundation; version 2 or later of  */
/*  the License.                                     */
/*                                                   */
/*  PJIRC is distributed in the hope that it will    */
/*  be useful, but WITHOUT ANY WARRANTY; without     */
/*  even the implied warranty of MERCHANTABILITY or  */
/*  FITNESS FOR A PARTICULAR PURPOSE.  See the GNU   */
/*  General Public License for more details.         */
/*                                                   */
/*  You should have received a copy of the GNU       */
/*  General Public License along with PJIRC; if      */
/*  not, write to the Free Software Foundation,      */
/*  Inc., 59 Temple Place, Suite 330, Boston,        */
/*  MA  02111-1307  USA                              */
/*                                                   */
/*****************************************************/

package irc.gui.pbtn;

import java.awt.*;

/**
 * Root panel for all PbtnComponents.
 */
public class PbtnPanel extends Panel
{
  /**
   * Black.
   */
  public static final int COLOR_BLACK=PbtnColorModel.COLOR_BLACK;
  /**
   * White.
   */
  public static final int COLOR_WHITE=PbtnColorModel.COLOR_WHITE;
  /**
   * Dark gray.
   */
  public static final int COLOR_DARK_GRAY=PbtnColorModel.COLOR_DARK_GRAY;
  /**
   * Gray.
   */
  public static final int COLOR_GRAY=PbtnColorModel.COLOR_GRAY;
  /**
   * Light gray.
   */
  public static final int COLOR_LIGHT_GRAY=PbtnColorModel.COLOR_LIGHT_GRAY;
  /**
   * Front.
   */
  public static final int COLOR_FRONT=PbtnColorModel.COLOR_FRONT;
  /**
   * Back.
   */
  public static final int COLOR_BACK=PbtnColorModel.COLOR_BACK;
  /**
   * Selected.
   */
  public static final int COLOR_SELECTED=PbtnColorModel.COLOR_SELECTED;
  /**
   * Event.
   */
  public static final int COLOR_EVENT=PbtnColorModel.COLOR_EVENT;
  /**
   * Close.
   */
  public static final int COLOR_CLOSE=PbtnColorModel.COLOR_CLOSE;
  /**
   * Voice.
   */
  public static final int COLOR_VOICE=PbtnColorModel.COLOR_VOICE;
  /**
   * Op.
   */
  public static final int COLOR_OP=PbtnColorModel.COLOR_OP;
  /**
   * Semiop.
   */
  public static final int COLOR_SEMIOP=PbtnColorModel.COLOR_SEMIOP;
  /**
   * ASL male.
   */
  public static final int COLOR_MALE=PbtnColorModel.COLOR_MALE;
  /**
   * ASL femeale.
   */
  public static final int COLOR_FEMEALE=PbtnColorModel.COLOR_FEMEALE;
  /**
   * ASL undefined.
   */
  public static final int COLOR_UNDEF=PbtnColorModel.COLOR_UNDEF;

  /**
   * Pbtn Configuration.
   */
  protected PbtnConfiguration _pbtnConfiguration;

  /**
   * Create a new PbtnPanel.
   * @param config global pbtn configuration.
   */
  public PbtnPanel(PbtnConfiguration config)
  {
    _pbtnConfiguration=config;
  }

  /**
   * Release this object. No further method call may be performed.
   */
  public void release()
  {
    _pbtnConfiguration=null;
  }

  /**
   * Get the formatted text from the formatted text code.
   * @param code text code.
   * @return formatted string.
   */
  public String getText(int code)
  {
    return _pbtnConfiguration.getText(code);
  }

  /**
   * Draw a 3d box at given position.
   * @param g where to draw.
   * @param x x position.
   * @param y y position.
   * @param w width.
   * @param h height.
   */
  protected void drawSeparator(Graphics g,int x,int y,int w,int h)
  {
    g.setColor(new Color(0x868686));
    g.drawLine(x+0,y+0,x+w-1,y+0);
    g.drawLine(x+0,y+0,x+0,y+1);
    g.drawLine(x+w-1,y+0,x+w-1,y+1);
    g.setColor(Color.black);
    g.drawLine(x+1,y+1,x+w-2,y+1);

    g.setColor(new Color(0x868686));
    g.drawLine(x+0,y+0,x+0,y+h-1);
    g.setColor(Color.black);
    g.drawLine(x+1,y+1,x+1,y+h-1);

    g.setColor(new Color(0xD7D3CB));
    g.drawLine(x+0,y+h-1,x+w-1,y+h-1);

    g.setColor(new Color(0xD7D3CB));
    g.drawLine(x+w-1,y+1,x+w-1,y+h-1);
  }

  /**
   * Return the i'th color from the color model.
   * @param col color index.
   * @return i'th color from color model.
   */
  public Color getColor(int col)
  {
    return _pbtnConfiguration.getColor(col);
  }

  /**
   * Get the current IRC color model.
   * @return the irc color model.
   */
  public PbtnColorModel getPbtnColorModel()
  {
    return _pbtnConfiguration.getColorModel();
  }
}

