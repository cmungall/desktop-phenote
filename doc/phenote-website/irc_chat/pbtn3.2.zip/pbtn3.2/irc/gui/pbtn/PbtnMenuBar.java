/*****************************************************/
/*          This java file is a part of the          */
/*                                                   */
/*           -  Plouf's Java IRC Client  -           */
/*                                                   */
/*   Copyright (C)  2002 - 2004 Philippe Detournay   */
/*                                                   */
/*         All contacts : theplouf@yahoo.com         */
/*                                                   */
/*  PJIRC is free software; you can redistribute     */
/*  it and/or modify it under the terms of the GNU   */
/*  General Public License as published by the       */
/*  Free Software Foundation; version 2 or later of  */
/*  the License.                                     */
/*                                                   */
/*  PJIRC is distributed in the hope that it will    */
/*  be useful, but WITHOUT ANY WARRANTY; without     */
/*  even the implied warranty of MERCHANTABILITY or  */
/*  FITNESS FOR A PARTICULAR PURPOSE.  See the GNU   */
/*  General Public License for more details.         */
/*                                                   */
/*  You should have received a copy of the GNU       */
/*  General Public License along with PJIRC; if      */
/*  not, write to the Free Software Foundation,      */
/*  Inc., 59 Temple Place, Suite 330, Boston,        */
/*  MA  02111-1307  USA                              */
/*                                                   */
/*****************************************************/

package irc.gui.pbtn;

import java.io.*;
import java.net.*;
import java.awt.*;
import java.util.*;
import java.awt.event.*;
import java.awt.image.*;
import irc.security.*;
import irc.style.*;
import irc.*;

/**
 * The menu bar.
 */
public class PbtnMenuBar extends PbtnPanel implements ActionListener,MouseListener,MouseMotionListener,Runnable,FormattedStringDrawerListener
{
	private ImageButton _connect=null;
	private ImageButton _about=null;
	private ImageButton _help=null;
	private ImageButton _channels=null;
	private ImageButton _dock=null;
	
	private Vector _btnVector;

	private int btn_ratio;
	private int btn_h;
	private int btn_w;
	private ImageLoader _loader;
	private int _pressedIndex;
	private boolean _closePressed;
	private boolean _dockPressed;
	private ListenerGroup _listeners;
	private boolean _connected;
	private boolean _title;
	private Image _buffer;
	private FormattedStringDrawer _drawer;
	private String _titleString;
	private DecodedLine _decodedTitle;
	private int _connectIndex;
	private int _chanlistIndex;
	private int _aboutIndex;
	private int _helpIndex;
	private int _titleLeft;
	private int _mouseDownX;
	private boolean _mouseScroll;
	private DrawResult _drawResult;
	private boolean _terminated;
	private boolean _redrawTitle;
	private Thread _scrollThread;
	private Object _scrollLock;
	private boolean _freeze;
	private int _scrollDelay;
	private String _buttonpath;
	private String _buttonext;
	private IRCConfiguration _ircConfiguration;

	/**
	 * Create a new PbtnMenuBar without title displayed.
	 * @param config the global irc configuration.
	 */
	public PbtnMenuBar(PbtnConfiguration config)
	{
		this(config,false);
	}

	/**
	 * Create a new PbtnMenuBar.
	 * @param config the global irc configuration.
	 * @param title true if this menu bar should display its own title, false otherwise.
	 */
	public PbtnMenuBar(PbtnConfiguration config,boolean title)
	{
		super(config);
		_btnVector=new Vector();
        setLayout( new FlowLayout(FlowLayout.LEFT, 0, 4) );
		btn_ratio=(config.getI("buttonratio") <= 100) ? config.getI("buttonratio") : 100 ;
		_titleLeft=0;
		_title=title;
		_mouseScroll=false;
		_titleString="";
		_ircConfiguration=config.getIRCConfiguration();
		_drawer=new FormattedStringDrawer(_ircConfiguration,_ircConfiguration.getDefaultStyleContext(),this);
		_decodedTitle=_drawer.decodeLine(_titleString);
		_connected=false;
		_pressedIndex=-1;
		_closePressed=false;
		_dockPressed=false;
		_listeners=new ListenerGroup();
		_loader=_ircConfiguration.getImageLoader();
		_buttonpath = config.getS("buttonpath");
		_buttonext = config.getS("buttonext");
		if(config.getB("showconnect")) drawDisconnectItem();
		if(config.getB("showchanlist")) drawChanListItem();
		if(config.getB("showabout")) drawAboutItem();
		if(config.getB("showhelp"))	drawHelpItem();
		if(config.getB("showdock")) drawDockButtonItem();
		if(config.getB("showcustombuttons")) drawCustomButtonItems();
		_scrollDelay=config.getI("scrollspeed");
		if(_scrollDelay!=0) _scrollDelay=1000/_scrollDelay;
		_drawResult=new DrawResult();
		addMouseListener(this);
		addMouseMotionListener(this);
		_terminated=false;
		_redrawTitle=false;
		_scrollLock=new Object();
		if(_scrollDelay>0)
		{
			_scrollThread=new Thread(this);
			_scrollThread.start();
		}
	}
	
	public void release()
	{
		removeMouseListener(this);
		removeMouseMotionListener(this);
		_btnVector.removeAllElements();
		super.release();
	}
	/**
	 * Set title.
	 * @param title title string.
	 * @param context title style context.
	 */
	public void setTitle(String title,StyleContext context)
	{
		_drawer.setStyleContext(context);
		_titleString=title;
		_decodedTitle=_drawer.decodeLine(_titleString);
		_buffer=null;
		repaint();
	}
	/**
	 * Add listener.
	 * @param lis listener to add.
	 */
	public void addPbtnMenuBarListener(PbtnMenuBarListener lis)
	{
		_listeners.addListener(lis);
	}
	/**
	 * Remove listener.
	 * @param lis listener to remove.
	 */
	public void removePbtnMenuBarListener(PbtnMenuBarListener lis)
	{
		_listeners.removeListener(lis);
	}
	/**
	 * Set the connected flag.
	 * @param b true if application is connected to the server, false otherwise.
	 */
	public void setConnected(boolean b)
	{
		_connected=b;
		_buffer=null;
		repaint();
	}
	
	public Dimension getPreferredSize()
	{
		if(_title)
			return new Dimension(16,getItemHeight()+getTitleHeight()+4);
		return new Dimension(16,getItemHeight()+4);
	}
	
	private int getClosePositionX()
	{
		int w=getSize().width;
		return w-18;
	}
	
	private int getClosePositionY()
	{
		return getY(0)+1;
	}
	
	private int getDockPositionX()
	{
		int w=getSize().width;
		if(!_pbtnConfiguration.getB("showclose")) return w-18;
		return w-18-18;
	}
	
	private int getDockPositionY()
	{
		return getY(0)+1;
	}
	
	private boolean isClosePressed(int x,int y)
	{
		if(!_pbtnConfiguration.getB("showclose")) return false;
		x-=getClosePositionX();
		if(x<0) return false;
		if(x>=16) return false;
		y-=getClosePositionY();
		if(y<0) return false;
		if(y>=16) return false;
		return true;
	}
	
	private boolean isDockPressed(int x,int y)
	{
		if(!_pbtnConfiguration.getB("showdock")) return false;
		x-=getDockPositionX();
		if(x<0) return false;
		if(x>=16) return false;
		y-=getDockPositionY();
		if(y<0) return false;
		if(y>=16) return false;
		return true;
	}
	
	private int getItemWidth()
	{
		return btn_w;
	}
	
	private int getItemHeight()
	{
		return btn_h + 4;
	}
	
	private int getIconWidth()
	{
		return 16;
	}
	
	private int getIconHeight()
	{
		return btn_h;
	}
	
	private int getX(int pos)
	{
		return pos*(getItemWidth()+8)+2;
	}
	
	private int getPos(int x)
	{
		return (x-2)/(getItemWidth()+8);
	}
	
	private int getY(int pos)
	{
		if(!_title)
			return 2;
		return 2+getTitleHeight()*0;
	}
	
	private int getTitleY()
	{
		// return 0;
		return getItemHeight()+4;
	}
	
	private int getTitleHeight()
	{
		return 18;
	}
	
	private int getIndex(int x)
	{
		int pos=getPos(x);
		if(pos<0) return -1;
		if(pos>4) return -1;
		x-=getX(pos);
		if(x>=getItemWidth()) return -1;
		return pos;
	}
	
	private int getIndex(int x,int y)
	{
		if(y<getY(0)) return -1;
		y-=getY(0);
		if(y>=getItemHeight()) return -1;
		return getIndex(x);
	}
	
	private void drawTitle(Graphics g,int y)
	{
		int w=getSize().width;
		
		g.setColor(_drawer.getColor(0));
		g.fillRect(0,y,w,getTitleHeight());
		g.setClip(0,y,w,getTitleHeight());
		_drawer.draw(_decodedTitle,g,5+_titleLeft,w-5+_titleLeft,y+getTitleHeight()-2,0,w-1,false,false,_drawResult);
		g.setClip(0,0,getSize().width,getSize().height);
		
		drawSeparator(g,0,y,w,getTitleHeight());
	}
	
	private void drawCloseButtonCross(Graphics g,int x,int y)
	{
		int w=13;
		int h=11;
		g.setColor(getColor(COLOR_CLOSE));
		g.fillRect(x,y,w,h);
		g.setColor(getColor(COLOR_BLACK));
		for(int i=0;i<4;i++)
		{
			g.drawLine(x+3+i,y+2+i,x+4+i,y+2+i);
			g.drawLine(x+9-i,y+2+i,x+10-i,y+2+i);
			g.drawLine(x+3+i,y+8-i,x+4+i,y+8-i);
			g.drawLine(x+9-i,y+8-i,x+10-i,y+8-i);
		}
	}
	
	private void drawDockButtonInternal(Graphics g,int x,int y)
	{
		int w=13;
		int h=11;
		g.setColor(getColor(COLOR_CLOSE));
		g.fillRect(x,y,w,h);
		g.setColor(getColor(COLOR_BLACK));
		int ox=4;
		int oy=1;
		g.drawRect(x+ox,y+oy,6,5);
		g.drawLine(x+ox+1,y+oy+1,x+ox+6,y+oy+1);
		ox=2;
		oy=4;
		g.setColor(getColor(COLOR_BLACK));
		g.drawRect(x+ox,y+oy,6,5);
		g.drawLine(x+ox+1,y+oy+1,x+ox+6,y+oy+1);
		g.setColor(getColor(COLOR_CLOSE));
		g.fillRect(x+ox+1,y+oy+2,5,3);
	}
	
	private void drawItem(Graphics g,int x,int y,boolean selected,String s)
	{
		int w=getItemWidth();
		int h=getItemHeight();
		int iw=getIconWidth();
		g.setColor(getColor(COLOR_FRONT));
		if(selected) g.setColor(getColor(COLOR_SELECTED));
		g.fillRect(x,y,w,h);
		g.setColor(getColor(COLOR_BLACK));
		g.drawRect(x,y,w-1,h-1);
		g.setColor(getColor(COLOR_WHITE));
		g.drawRect(x+1,y+1,w-3,h-3);
		g.drawLine(x+iw+2,y+1,x+iw+2,y+h-2);
		int sw=g.getFontMetrics().stringWidth(s);
		w-=(5+iw);
		g.drawString(s,x+iw+3+(w-sw)/2,y+h-4);
	}
	
	private void drawDisconnectItem()
	{
		if (_connect == null) _connect=addButton(getText(PbtnTextProvider.GUI_DISCONNECT), _buttonpath);
		_connect.setCaption(getText(PbtnTextProvider.GUI_DISCONNECT));
		_connect.repaint();
	}
	
	private void drawConnectItem()
	{
		if (_connect == null) _connect=addButton(getText(PbtnTextProvider.GUI_CONNECT), _buttonpath);
		_connect.setCaption(getText(PbtnTextProvider.GUI_CONNECT));
		_connect.repaint();
	}
	
	private void drawChanListItem()
	{
		if (_channels == null) _channels=addButton(getText(PbtnTextProvider.GUI_CHANNELS), _buttonpath);
		_channels.setCaption(getText(PbtnTextProvider.GUI_CHANNELS));
		_channels.repaint();
	}
	
	private void drawAboutItem()
	{
		if (_about == null) _about=addButton(getText(PbtnTextProvider.GUI_ABOUT), _buttonpath);
		_about.setCaption(getText(PbtnTextProvider.GUI_ABOUT));
		_about.repaint();
	}
	
	private void drawHelpItem()
	{
		if (_help == null) _help=addButton(getText(PbtnTextProvider.GUI_HELP), _buttonpath);
		_help.setCaption(getText(PbtnTextProvider.GUI_HELP));
		_help.repaint();
	}
	
	private void drawSmallButton(Graphics g,int x,int y,boolean pressed)
	{
		int w=16;
		int h=16;
		if(!pressed)
		{
			g.setColor(getColor(COLOR_WHITE));
			g.drawLine(x+0,y+1,x+w-2,y+1);
			g.drawLine(x+0,y+1,x+0,y+h-2);
			g.setColor(getColor(COLOR_BLACK));
			g.drawLine(x+w-1,y+h-2,x+w-1,y+1);
			g.drawLine(x+w-1,y+h-2,x+0,y+h-2);
			g.setColor(getColor(COLOR_DARK_GRAY));
			g.drawLine(x+w-2,y+h-3,x+w-2,y+2);
			g.drawLine(x+w-2,y+h-3,x+1,y+h-3);
		}
		else
		{
			g.setColor(getColor(COLOR_BLACK));
			g.drawLine(x+0,y+1,x+w-2,y+1);
			g.drawLine(x+0,y+1,x+0,y+h-2);
			g.setColor(getColor(COLOR_WHITE));
			g.drawLine(x+w-1,y+h-2,x+w-1,y+1);
			g.drawLine(x+w-1,y+h-2,x+0,y+h-2);
			g.setColor(getColor(COLOR_DARK_GRAY));
			g.drawLine(x+1,y+2,x+1,y+h-3);
			g.drawLine(x+1,y+2,x+w-2,y+2);
		}
	}
	
	private void drawCloseButtonItem(Graphics g,int x,int y,boolean pressed)
	{
		drawSmallButton(g,x,y,pressed);
		if(!pressed)
			drawCloseButtonCross(g,x+1,y+2);
		else
			drawCloseButtonCross(g,x+2,y+3);
	}
	
	private void drawDockButtonItem(Graphics g,int x,int y,boolean pressed)
	{
		drawSmallButton(g,x,y,pressed);
		if(!pressed)
			drawDockButtonInternal(g,x+1,y+2);
		else
			drawDockButtonInternal(g,x+2,y+3);
		drawDockButtonItem();
	}
	
	private void drawDockButtonItem()
	{
		if (_dock == null)
		{
			_dock=addButton(getText(PbtnTextProvider.GUI_FLOAT), _buttonpath);
		}
		_dock.setCaption(getText(PbtnTextProvider.GUI_FLOAT));
		_dock.repaint();
	}

	private void drawCustomButtonItems()
	{
		if (_btnVector.isEmpty())
		{
			for(int j=0;j<_pbtnConfiguration.getButtonVector().size();j++)
			{
				String[] cmds=(String[])_pbtnConfiguration.getButtonVector().elementAt(j);
				ImageButton btn=addButton(cmds[0], _buttonpath);
				btn.setCaption(cmds[0]);
				btn.repaint();
				_btnVector.addElement(btn);
			}
		}
		else
		{
			Enumeration btns=_btnVector.elements();
			while(btns.hasMoreElements())
			{
				ImageButton btn= (ImageButton)btns.nextElement();
				btn.repaint();
			}
		}
	}
		
	public void actionPerformed(ActionEvent e)
	{	 
		EventDispatcher.dispatchEventAsync(this,"actionPerformedEff",new Object[] {e});
	}
	
	/**
	 * Internally used.
	 */
	public void actionPerformedEff(ActionEvent e)
	{
		String cmd=e.getActionCommand();
		if(e.getSource() == _connect)
		{
			if(_pbtnConfiguration.getB("showconnect")) _listeners.sendEventAsync("connectionClicked",this);
			if (_connected) 
			{
				drawDisconnectItem();
			}
			else
			{
				drawConnectItem();
			}
		}
		if(e.getSource() == _about)
		{
			if(_pbtnConfiguration.getB("showabout")) _listeners.sendEventAsync("aboutClicked",this);
		}
		if(e.getSource() == _help)
		{
			if(_pbtnConfiguration.getB("showhelp")) _listeners.sendEventAsync("helpClicked",this);
		}
		if(e.getSource() == _channels)
		{
			if(_pbtnConfiguration.getB("showchanlist")) _listeners.sendEventAsync("chanListClicked",this);
		}
		if(e.getSource() == _dock)
		{
			if(_pbtnConfiguration.getB("showdock"))  _listeners.sendEventAsync("dockClicked",this);
		}
		
		for(int j=0;j<_pbtnConfiguration.getButtonVector().size();j++)
		{
			String[] cmds=(String[])_pbtnConfiguration.getButtonVector().elementAt(j);
			if(cmds[0].equals(cmd))
			{
				if(_pbtnConfiguration.getB("showcustombuttons"))  _listeners.sendEventAsync("customClicked",this,cmds);
			}
		}

	}

	private boolean checkFile(String file)
	{	
		System.out.println("file="+file);
		FileHandler _file=_ircConfiguration.getFileHandler();
		InputStream stream=_file.getInputStream(file);
		if (stream == null)
		{
			return false;
		}
		else 
		{
			return true;
		}
	}
	
	private ImageButton addButton(String txt, String file) 
	{
		int h=-1;
		ImageButton btn;
		if (checkFile(file+"_up."+_buttonext))
		{
			Image btn_down = _loader.getImage(file+"_down."+_buttonext);
			Image btn_grey = _loader.getImage(file+"_grey."+_buttonext);
			Image btn_over = _loader.getImage(file+"_over."+_buttonext);
			Image btn_up = _loader.getImage(file+"_up."+_buttonext);
			
			while (h < 0)
			{
				h = btn_up.getHeight(null);
			}
			int w = btn_up.getWidth(null);
			h = btn_up.getHeight(null);
			w = btn_up.getWidth(null);
			if (btn_ratio == 0)
			{
				btn_h = 18;
				float mw = ((float) w/(float) h/18);
				btn_w = (int) mw;
			}
			else
			{
				float mh = (float) btn_ratio/100*(float) h;
				float mw = (float) btn_ratio/100*(float) w;
				if ((int) mw >= btn_w)	btn_w = (int) mw;
				if ((int) mh >= btn_h) btn_h = (int) mh;
			} 
			btn = new ImageButton(btn_over, btn_up, btn_down, btn_w, btn_h, txt);
		}
		else
		{
			btn_w=65;
			btn_h=16;
			btn = new ImageButton(btn_w, btn_h, txt);
		}		

		btn.addActionListener(this);
		btn.setBGColor(getColor(COLOR_BACK));
		btn.setFontColor(getColor(COLOR_WHITE));

		this.add(btn);
		btn.repaint();
		return btn;
	}
	
	public void paint(Graphics g)
	{
		update(g);
	}
	
	public void update(Graphics ug)
	{
		int w=getSize().width;
		int h=getSize().height;
	
		if(_buffer!=null)
		{
			if((_buffer.getWidth(this)!=w) || (_buffer.getHeight(this)!=h)) _buffer=null;
		}
		
		if(_buffer==null)
		{
			Graphics g;
			try
			{
				_buffer=createImage(w,h);
				g=_buffer.getGraphics();
			}
			catch(Throwable e)
			{
				return;
			}
			g.setFont(new Font("",Font.PLAIN,12));
			//   g.setColor(new Color(0x084079));
			g.setColor(getColor(COLOR_BACK));
			g.fillRect(0,0,w,h);
		
			if(_pbtnConfiguration.getB("showconnect"))
			{
				if(!_connected)
				{
					drawConnectItem();
				}
				else
				{
					drawDisconnectItem();
				}
			}
			if(_pbtnConfiguration.getB("showchanlist")) drawChanListItem();
			if(_pbtnConfiguration.getB("showabout")) drawAboutItem();
			if(_pbtnConfiguration.getB("showhelp")) drawHelpItem();
			if(_pbtnConfiguration.getB("showclose")) drawCloseButtonItem(g,getClosePositionX(),getClosePositionY(),_closePressed);
			if(_pbtnConfiguration.getB("showdock")) drawDockButtonItem(g,getDockPositionX(),getDockPositionY(),_dockPressed);			
			if(_pbtnConfiguration.getB("showcustombuttons")) drawCustomButtonItems();
			if(_title) drawTitle(g,getTitleY());
		}
		else
		{
			Graphics g=_buffer.getGraphics();
			if(_redrawTitle) drawTitle(g,getTitleY());
		}
		_redrawTitle=false;
		if(_buffer!=null) ug.drawImage(_buffer,0,0,this);
	}
	
	public void mouseClicked(MouseEvent e)
	{
	}
	
	public void mouseEntered(MouseEvent e)
	{
	}
	
	public void mouseExited(MouseEvent e)
	{
	}
	
	public void mousePressed(MouseEvent e)
	{
		_pressedIndex=getIndex(e.getX(),e.getY());
		_closePressed=isClosePressed(e.getX(),e.getY());
		_dockPressed=isDockPressed(e.getX(),e.getY());
		_buffer=null;
		if(_title && (e.getY()>=getTitleY()))
		{
			_mouseDownX=e.getX();
			_mouseScroll=true;
		}
		repaint();
	}
	
	public void mouseReleased(MouseEvent e)
	{
		_mouseScroll=false;
		int index=getIndex(e.getX(),e.getY());
		boolean close=isClosePressed(e.getX(),e.getY());
		boolean dock=isDockPressed(e.getX(),e.getY());
		if(close) _listeners.sendEventAsync("closeClicked",this);
		if(dock) _listeners.sendEventAsync("dockClicked",this);
		_closePressed=false;
		_dockPressed=false;
		_pressedIndex=-1;
		_buffer=null;
		repaint();
	}
	
	public void mouseMoved(MouseEvent e)
	{
		if(_title && (e.getY()>=getTitleY()))
		{
			if(!getCursor().equals(new Cursor(Cursor.E_RESIZE_CURSOR)))
				setCursor(new Cursor(Cursor.E_RESIZE_CURSOR));
		}
		else
		{
			if(!getCursor().equals(new Cursor(Cursor.DEFAULT_CURSOR)))
				setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
		}
	}
	
	/**
	 * Release any resources used by this component.
	 */
	public void dispose()
	{
		_terminated=true;
	}
	
	private void scrollTitle(int deltaX)
	{
		synchronized(_scrollLock)
		{
			if(_drawResult.rectangle==null) return;
			_titleLeft-=deltaX;
			/**--- WRAP BEHAVIOUR ---**/
			int min=-_drawResult.rectangle.width;
			int max=getSize().width;
			if(_titleLeft>max) _titleLeft=min;
			if(_titleLeft<min) _titleLeft=max;
			
			/**--- CLAMP BEHAVIOUR ---**/
			/*int min=-_drawResult.rectangle.width;
			int max=0;
			if(_titleLeft>max) _titleLeft=max;
			if(_titleLeft<min) _titleLeft=min;*/
			_redrawTitle=true;
			repaint();
		}
	}
	
	public void mouseDragged(MouseEvent e)
	{
		if(!_mouseScroll) return;
		if(_drawResult.rectangle==null) return;
		int deltaX=_mouseDownX-e.getX();
		scrollTitle(deltaX);
		_freeze=true;
		_mouseDownX=e.getX();
	}
	
	public void run()
	{
		while(!_terminated)
		{
			if(!_freeze) scrollTitle(4);
			try
			{
				if(_freeze)
				{
					Thread.sleep(2000);
					_freeze=false;
				}
				else
					Thread.sleep(_scrollDelay);
			}
			catch(InterruptedException ex)
			{
			}
		}
	}
	
	public Boolean displayUpdated(Object handle,Integer what)
	{
		if(_drawResult==null) return Boolean.FALSE;
		for(int i=0;i<_drawResult.updateHandles.size();i++)
		{
			if(_drawResult.updateHandles.elementAt(i)==handle)
			{
				_redrawTitle=true;
				repaint();
				return Boolean.TRUE;
			}
		}
		return Boolean.FALSE;
	}
}
